// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//Shayna Mitchell CS 405 Week Four Edit of Exceptions.cpp


#include <stdexcept> //added for runtime error in assignment
#include <iostream>



//Here I added a new class named ShaysException
class ShaysException : public std::exception {
    public:
    const char* what() const noexcept override {
        return "Error thrown here";
    }
};


bool do_even_more_custom_application_logic()
{
  // TODO: Throw any standard exception
  //Throwing an error here to display a message to the user rather than the program simply crashing. 
  //The program with stop running at this point but it will stop with an explanation to the user.
  //The code can then be handled later gracefully rather than the program simply crashing - "e.what()"

  throw std::invalid_argument("Invalid Argument here.");


  //this line will not run or this message will not be displayed now
  std::cout << "Running Even More Custom Application Logic." << std::endl;

  return true;
}


void do_custom_application_logic()
{
  // TODO: Wrap the call to do_even_more_custom_application_logic()
  //  with an exception handler that catches std::exception, displays
  //  a message and the exception.what(), then continues processing

  //catch inside of a try-catch block to prevent the program from crashing
  //display a message to the user instead of the program simply crashing

  std::cout << "Running Custom Application Logic." << std::endl;

  //added a wrapped try catch block here:
  try{
    
    if(do_even_more_custom_application_logic())
  {
    std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
  }
  //added } and catch block here
}
catch (const std::exception& e) {
//added here, show error message to user and show the actual error that was thrown
    std::cout << "exception caught here: " << e.what() << std::endl;
}
  // TODO: Throw a custom exception derived from std::exception
  //  and catch it explictly in main

  //here see my exception class at the end of the code
  throw ShaysException();

  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  // TODO: Throw an exception to deal with divide by zero errors using
  //  a standard C++ defined exception

  //added here, check if the denominator is zero

  if (den == 0) {
    //added a thrown error here 
    throw std::runtime_error("Division error here.");

  }

  return (num / den);
  //now the program will throw this error instead of simply crashing and the user will see this message.
}

void do_division() noexcept
{
  //  TODO: create an exception handler to capture ONLY the exception thrown
  //  by divide.

  float numerator = 10.0f;
  float denominator = 0;


  //added in a try catch error block to handle errors gracefully
  //auto is equivalent to float in C++

    try {

    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    //added catch here as exception
    catch (const std::exception& e) {
    std::cout << "division caught here: " << e.what() << std::endl;
    }

}



int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // TODO: Create exception handlers that catch (in this order):
  //  your custom exception
  //  std::exception
  //  uncaught exception 
  //  that wraps the whole main function, and displays a message to the console.

  try {
  do_division();
  do_custom_application_logic();
    }
//added catch here:
catch (const ShaysException& e) {
    std::cout << "caught customized exception in main: " << e.what() << std::endl;
    }
//added another catch here:
catch (const std:: exception& e) {
    std::cout << "exception caught here: " << e.what() << std::endl;
    }
//added an exception here that is uncaught
catch (...) {
    std::cout << "error has occurred here in main." << std::endl;
    }

}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
