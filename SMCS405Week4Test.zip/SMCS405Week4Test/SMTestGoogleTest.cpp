//SMCS405 added in comments and changes to provided code Week 4 UnitTesting

// Uncomment the next line to use precompiled headers
//#include "pch.h" I commented this line out
// uncomment the next line if you do not use precompiled headers
//I uncommented this line to use google test:
#include "gtest/gtest.h" 
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
//Does it work correctly
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
//Does it work correctly
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//  FAIL();
//}

// TODO: Create a test to verify adding a single value to an empty collection
//Does it work correctly
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  // is the collection empty?
  //First an empty collection:
  ASSERT_TRUE(collection->empty());

  ASSERT_EQ(collection->size(), 0);

  // if empty, the size must be 0
  //entry has a single random insert
  add_entries(1);

  // is the collection still empty?
  // if not empty, what must the size be?
  //Now it is not empty anymore:
  EXPECT_FALSE(collection->empty());

  //and added one item so the size is now 1.
  EXPECT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
//Does it work correctly
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  //Here 5 values are added randomly
  add_entries(5);

  //no empty vector
  EXPECT_FALSE(collection->empty());

  //new vector size is 5:
  EXPECT_EQ(collection->size(), 5);

}

// TODO: Create a test to verify that max size is greater than or equal to 
//size for 0, 1, 5, 10 entries
//Does it work correctly
TEST_F(CollectionTest, CheckMaxSize)
{
  //Check max size with this test
  std:: vector<int>::size_type maxSize = collection->max_size();

  //zero entries
  // removed this line as it did not work properly add_entries(0);
  EXPECT_LE(collection->size(), maxSize);

  //clear
  collection->clear();
  //1 entry
  add_entries(1);
  EXPECT_LE(collection->size(), maxSize);

  //clear
  collection->clear();
  //5 entries
  add_entries(5);
  EXPECT_LE(collection->size(), maxSize);

  //clear
  collection->clear();
  //10 entries
  add_entries(10);
  EXPECT_LE(collection->size(), maxSize);

}

// TODO: Create a test to verify that capacity is greater than or equal to 
//size for 0, 1, 5, 10 entries
//Does it work correctly
TEST_F(CollectionTest, CapacityCheck)
{
  std::vector<int> testVec;

  //0 ENTRIES
  ASSERT_GE(testVec.capacity(), testVec.size());

  testVec.push_back(1);

  //1 entry
  ASSERT_GE(testVec.capacity(), testVec.size());

  for (int i = 0; i < 4; ++i)
  testVec.push_back(i);

  //5 entries
  ASSERT_GE(testVec.capacity(), testVec.size());

  for (int i = 0; i < 5; ++i)
  testVec.push_back(i);

  //10 entries
  ASSERT_GE(testVec.capacity(), testVec.size());

}

// TODO: Create a test to verify resizing increases the collection
//does the request actually resize it
TEST_F(CollectionTest, ResizeSize)
{
  //resize it to 3
  collection->resize(3);
  EXPECT_EQ(collection->size(), 3);

  //resize 10
  collection->resize(10);
  EXPECT_EQ(collection->size(), 10);

}

// TODO: Create a test to verify resizing decreases the collection
//show that when resizing, it actually becomes smaller
TEST_F(CollectionTest, ResizeSizeDecr)
{
  //Begin 5
  for (int i = 0; i < 5; ++i) {
    collection->push_back(i);
  }

  //change to 2
  collection ->resize(2);

  //Watch behavior with size at 2
  EXPECT_EQ(collection->size(), 2);
}

// TODO: Create a test to verify resizing decreases the collection to zero
//Test if is sized to 0
TEST_F(CollectionTest, ResizeZero)
{
  //Begin 4
  for (int i = 0; i < 4; ++i) {
    collection->push_back(i);
  }
  //now 0
  collection->resize(0);

  //Watch behavior with size 0
  EXPECT_EQ(collection->size(), 0);

}

// TODO: Create a test to verify clear erases the collection
//Does .clear(which is called here) actually erase it?
TEST_F(CollectionTest, VerifyClear)
{
  //create something to test
  collection->push_back(10);
  collection->push_back(20);
  collection->push_back(30);

  //clear it all
  collection->clear();

  //Did it work?
  EXPECT_EQ(collection->size(), 0);
  EXPECT_TRUE(collection->empty());

}

// TODO: Create a test to verify erase(begin,end) erases the collection
//Does begin end actually erase it?
TEST_F(CollectionTest, VerifyErase)
{
  //create something to test
  collection->push_back(10);
  collection->push_back(20);
  collection->push_back(30);

  //Look to see that there is actually something here
  ASSERT_FALSE(collection->empty());
  ASSERT_EQ(collection->size(), 3);

  //Now erase everything by using begin and end 
  collection->erase(collection->begin(), collection->end());

  //Did it work? Is it actually erased?
  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);

}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
//look at the results comparing capacity versus collection size
TEST_F(CollectionTest, VerifyReserveCapacity)
{
  //first store capacity and size to be able to check
  size_t initialSize = collection->size();
  size_t initialCapacity = collection->capacity();

  //reserve the capacity
  collection->reserve(100);

  //create a new capacity amount
  EXPECT_GE(collection->capacity(), 100);

  //Did the initial size of the collection change? Because it should not.
  EXPECT_EQ(collection->size(), initialSize);

}

// TODO: Create a test to verify the std::out_of_range exception is thrown 
//when calling at() with an index out of bounds
// NOTE: This is a negative test
//.at() checks for the exception
TEST_F(CollectionTest, VerifyExceptionThrown)
{
  //First the collection is to be empty
  ASSERT_TRUE(collection->empty());

  //if accessing index 0, then exception std::out_of_range should be thrown here
  EXPECT_THROW({
    auto value = collection->at(0);
  }, std::out_of_range);
  //Here we should have thrown the error and that means it is working properly 
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

//First test
//Make sure the collection holds values in the correct order, a positive test 
//because I do not want this test to purposefully throw an exception
TEST_F(CollectionTest, VerifyValueOrder)
{
  //collection needs values first
  collection->push_back(10);
  collection->push_back(20);
  collection->push_back(30);

  //What is the order?
  EXPECT_EQ(collection->at(0), 10);
  EXPECT_EQ(collection->at(1), 20);
  EXPECT_EQ(collection->at(2), 30);
}

//Second Test
//I want to purposefully throw an exception as this is a negative test
TEST_F(CollectionTest, AccessEmptyVector)
{
  //Try to access empty vector
  //Purposefully throw exception because of it
  EXPECT_THROW(collection->at(0), std::out_of_range);
}
//All tests now run well through g++ and googletest